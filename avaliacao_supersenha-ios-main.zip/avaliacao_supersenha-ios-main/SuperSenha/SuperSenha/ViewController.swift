//
//  ViewController.swift
//  SuperSenha
//
//  Created by Douglas Frari on 8/7/21.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    // Outlets necessarios:
    @IBOutlet weak var tfTotalPasswords: UITextField!
    @IBOutlet weak var tfNumberOfCharacters: UITextField!
    @IBOutlet weak var swLetters: UISwitch!
    @IBOutlet weak var swNumbers: UISwitch!
    @IBOutlet weak var swSpecialCharacters: UISwitch!
    @IBOutlet weak var swCaptitalLetters: UISwitch!
    @IBOutlet weak var btnGeneratePassword: UIButton!
    
    
    override func viewDidLoad() {
        self.tfTotalPasswords.delegate = self
        self.tfNumberOfCharacters.delegate = self
        
        let toolbar: UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0,  width: self.view.frame.size.width, height: 30))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneBtn: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(dismissKeyboard))
        toolbar.setItems([flexibleSpace, doneBtn], animated: false)
        toolbar.sizeToFit()
        self.tfTotalPasswords.inputAccessoryView = toolbar
        self.tfNumberOfCharacters.inputAccessoryView = toolbar
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let vc = segue.destination as! PasswordViewController
        
        // forma mais segura (usar if let)
        if let numberOfPasswords = Int(tfTotalPasswords.text!) {
            // se conseguir obter o valor do campo e converter para inteiro
            vc.numberOfPasswords = numberOfPasswords
        }
        if let numberOfCharacters = Int(tfNumberOfCharacters.text!) {
            vc.numberOfCharacters = numberOfCharacters
        }
        vc.useNumbers = swNumbers.isOn
        vc.useCapitalLetters = swCaptitalLetters.isOn
        vc.useLetters = swLetters.isOn
        vc.useSpecialCharacters = swSpecialCharacters.isOn
        
        // forcar encerrar o modo de edicao // remove o foco e libera teclado
        view.endEditing(true)
        
        //view.becomeFirstResponder() // para fechar o teclado
        
    }
    
    @IBAction func tfTotalPasswordsTrigger(_ sender: Any) {
        verifyTextFieldTotalPasswords()
    }
    
    @IBAction func tfNumberOfCharactersTrigger(_ sender: Any) {
        verifyTextFieldNumberOfCharacters()
    }
    
    @IBAction func swLettersTrigger(_ sender: Any) {
        verifySwitches()
    }
    
    @IBAction func swNumbersTrigger(_ sender: Any) {
        verifySwitches()
    }
    
    @IBAction func swSpecialCharactersTrigger(_ sender: Any) {
        verifySwitches()
    }
    
    @IBAction func swCapitalLettersTrigger(_ sender: Any) {
        verifySwitches()
    }
    
    func verifyTextFieldTotalPasswords() {
        let totalPasswords:String = self.tfTotalPasswords.text ?? ""
        
        if Int(totalPasswords) ?? 0 == 0 || Int(totalPasswords) ?? 0 > 99
        {
            let dialogMessage = UIAlertController(title: "Atenção", message: "Valores não aceitáveis para a opção Quantidade de senhas: zero ou maior que 99.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                self.tfTotalPasswords.text = ""
                self.tfTotalPasswords.becomeFirstResponder()
            })
            dialogMessage.addAction(ok)
            self.present(dialogMessage, animated: true, completion: nil)
        }
    }
    
    func verifyTextFieldNumberOfCharacters() {
        let numberCharacters:String = self.tfNumberOfCharacters.text ?? ""
        
        if Int(numberCharacters) ?? 0 == 0 || Int(numberCharacters) ?? 0 > 16
        {
            let dialogMessage = UIAlertController(title: "Atenção", message: "Valores não aceitáveis para a opção Total de caracteres: zero ou maior que 16.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                self.tfNumberOfCharacters.text = ""
                self.tfNumberOfCharacters.becomeFirstResponder()
            })
            dialogMessage.addAction(ok)
            self.present(dialogMessage, animated: true, completion: nil)
        }
    }
    
    func verifySwitches() {
        if !swLetters.isOn && !swNumbers.isOn && !swCaptitalLetters.isOn && !swSpecialCharacters.isOn
        {
            buttonDisabledState()
        }
        else
        {
            buttonOriginalState()
        }
    }
    
    func buttonOriginalState() {
        self.btnGeneratePassword.isEnabled = true
        self.btnGeneratePassword.backgroundColor = UIColor(named: "Main")
    }
    
    func buttonDisabledState() {
        self.btnGeneratePassword.isEnabled = false
        self.btnGeneratePassword.backgroundColor = .gray
    }
    
    @objc func dismissKeyboard() {
        self.tfTotalPasswords.resignFirstResponder()
        self.tfNumberOfCharacters.resignFirstResponder()
    }
}

