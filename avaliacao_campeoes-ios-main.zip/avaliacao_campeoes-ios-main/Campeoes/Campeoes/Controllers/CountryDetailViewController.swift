//
//  CountryDetailViewController.swift
//  Campeoes
//
//  Created by Douglas Frari on 8/7/21.
//

import UIKit

class CountryDetailViewController: UIViewController {

    @IBOutlet weak var ivCountry: UIImageView!
    @IBOutlet weak var lbCountry: UILabel!
    @IBOutlet weak var lbWorldCups: UILabel!
    @IBOutlet weak var lbYears: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var worldCups: [WorldCup]!
    var countryWorldCups: [WorldCup] = []
    var winner: String!
    var vitoriasAcumuladas: Int = 0
    var dadosConquistas: String = ""
    var years:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for worldCup in worldCups {
            if winner == worldCup.winner {
                vitoriasAcumuladas += 1
                dadosConquistas += "País: \(worldCup.country) - ... \n\n"
                countryWorldCups.append(worldCup)
                years = years == "" ? "\(worldCup.year)" : "\(worldCup.year) - \(years)"
            }
        }
        
        self.tableView.reloadData()
        self.ivCountry.image = UIImage(named: winner)
        self.lbCountry.text = winner
        self.title = winner
        self.lbWorldCups.text = "Copas do mundo conquistadas: \(vitoriasAcumuladas)"
        self.lbYears.text = years
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension CountryDetailViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // total de secoes disponiveis
        return countryWorldCups.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // numero de linhas para a secao
        print(section)
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // recuperando o Game que se encontra em algum Match (oitavas de final, quartas, semi...)
        let match = countryWorldCups[indexPath.section].matches[countryWorldCups[indexPath.section].matches.count - 1]
        let game = match.games[match.games.count - 1]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! GamesTableViewCell
        cell.printCellValues(with: game)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        // obter um nome para secao
        let country = "\(countryWorldCups[section].country), \(countryWorldCups[section].year)"
        return country
    }
    
}
