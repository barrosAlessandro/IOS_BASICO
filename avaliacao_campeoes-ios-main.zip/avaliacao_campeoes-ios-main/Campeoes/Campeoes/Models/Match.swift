//
//  Match.swift
//  Campeoes
//
//  Created by Douglas Frari on 7/24/21.
//

import Foundation

struct Match: Codable {
    let stage: String
    let games: [Game]
}
